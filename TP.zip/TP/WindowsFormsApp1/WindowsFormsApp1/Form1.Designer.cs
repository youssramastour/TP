﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxville = new System.Windows.Forms.ComboBox();
            this.listville = new System.Windows.Forms.ListBox();
            this.textNom = new System.Windows.Forms.TextBox();
            this.groupBoxLangue = new System.Windows.Forms.GroupBox();
            this.checkBoxC = new System.Windows.Forms.CheckBox();
            this.checkCPLUS = new System.Windows.Forms.CheckBox();
            this.checkC = new System.Windows.Forms.CheckBox();
            this.textadresse = new System.Windows.Forms.TextBox();
            this.groupBoxgenre = new System.Windows.Forms.GroupBox();
            this.radiohomme = new System.Windows.Forms.RadioButton();
            this.radioButtonFemme = new System.Windows.Forms.RadioButton();
            this.labelAdrsse = new System.Windows.Forms.Label();
            this.labelNom = new System.Windows.Forms.Label();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonAfficher = new System.Windows.Forms.Button();
            this.buttonFermer = new System.Windows.Forms.Button();
            this.buttoninitia = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBoxLangue.SuspendLayout();
            this.groupBoxgenre.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBoxville);
            this.groupBox1.Controls.Add(this.listville);
            this.groupBox1.Controls.Add(this.textNom);
            this.groupBox1.Controls.Add(this.groupBoxLangue);
            this.groupBox1.Controls.Add(this.textadresse);
            this.groupBox1.Controls.Add(this.groupBoxgenre);
            this.groupBox1.Controls.Add(this.labelAdrsse);
            this.groupBox1.Controls.Add(this.labelNom);
            this.groupBox1.Location = new System.Drawing.Point(16, 36);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(685, 329);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Details de l\'utilisateur";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 114);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Ville";
            // 
            // comboBoxville
            // 
            this.comboBoxville.FormattingEnabled = true;
            this.comboBoxville.Items.AddRange(new object[] {
            "Casablanca",
            "Mohammadia",
            "Rabat",
            "Oujda"});
            this.comboBoxville.Location = new System.Drawing.Point(88, 114);
            this.comboBoxville.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxville.Name = "comboBoxville";
            this.comboBoxville.Size = new System.Drawing.Size(160, 24);
            this.comboBoxville.TabIndex = 8;
            // 
            // listville
            // 
            this.listville.FormattingEnabled = true;
            this.listville.ItemHeight = 16;
            this.listville.Items.AddRange(new object[] {
            "Casablanca",
            "Mohammadia",
            "Rabat",
            "Oujda"});
            this.listville.Location = new System.Drawing.Point(89, 186);
            this.listville.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listville.Name = "listville";
            this.listville.Size = new System.Drawing.Size(159, 116);
            this.listville.TabIndex = 6;
            this.listville.SelectedIndexChanged += new System.EventHandler(this.listville_SelectedIndexChanged);
            // 
            // textNom
            // 
            this.textNom.Location = new System.Drawing.Point(89, 30);
            this.textNom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textNom.Name = "textNom";
            this.textNom.Size = new System.Drawing.Size(132, 22);
            this.textNom.TabIndex = 4;
            // 
            // groupBoxLangue
            // 
            this.groupBoxLangue.Controls.Add(this.checkBoxC);
            this.groupBoxLangue.Controls.Add(this.checkCPLUS);
            this.groupBoxLangue.Controls.Add(this.checkC);
            this.groupBoxLangue.Location = new System.Drawing.Point(399, 143);
            this.groupBoxLangue.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxLangue.Name = "groupBoxLangue";
            this.groupBoxLangue.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxLangue.Size = new System.Drawing.Size(267, 123);
            this.groupBoxLangue.TabIndex = 7;
            this.groupBoxLangue.TabStop = false;
            this.groupBoxLangue.Text = "Langue";
            // 
            // checkBoxC
            // 
            this.checkBoxC.AutoSize = true;
            this.checkBoxC.Location = new System.Drawing.Point(40, 63);
            this.checkBoxC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkBoxC.Name = "checkBoxC";
            this.checkBoxC.Size = new System.Drawing.Size(69, 21);
            this.checkBoxC.TabIndex = 2;
            this.checkBoxC.Text = ".Net C";
            this.checkBoxC.UseVisualStyleBackColor = true;
            // 
            // checkCPLUS
            // 
            this.checkCPLUS.AutoSize = true;
            this.checkCPLUS.Location = new System.Drawing.Point(40, 43);
            this.checkCPLUS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkCPLUS.Name = "checkCPLUS";
            this.checkCPLUS.Size = new System.Drawing.Size(85, 21);
            this.checkCPLUS.TabIndex = 1;
            this.checkCPLUS.Text = ".Net C++";
            this.checkCPLUS.UseVisualStyleBackColor = true;
            // 
            // checkC
            // 
            this.checkC.AutoSize = true;
            this.checkC.Location = new System.Drawing.Point(40, 25);
            this.checkC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkC.Name = "checkC";
            this.checkC.Size = new System.Drawing.Size(77, 21);
            this.checkC.TabIndex = 0;
            this.checkC.Text = ".Net C#";
            this.checkC.UseVisualStyleBackColor = true;
            this.checkC.CheckedChanged += new System.EventHandler(this.buttonAfficher_Click);
            // 
            // textadresse
            // 
            this.textadresse.Location = new System.Drawing.Point(89, 71);
            this.textadresse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textadresse.Name = "textadresse";
            this.textadresse.Size = new System.Drawing.Size(132, 22);
            this.textadresse.TabIndex = 5;
            // 
            // groupBoxgenre
            // 
            this.groupBoxgenre.Controls.Add(this.radiohomme);
            this.groupBoxgenre.Controls.Add(this.radioButtonFemme);
            this.groupBoxgenre.Location = new System.Drawing.Point(399, 33);
            this.groupBoxgenre.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxgenre.Name = "groupBoxgenre";
            this.groupBoxgenre.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxgenre.Size = new System.Drawing.Size(252, 86);
            this.groupBoxgenre.TabIndex = 6;
            this.groupBoxgenre.TabStop = false;
            this.groupBoxgenre.Text = "Genre";
            // 
            // radiohomme
            // 
            this.radiohomme.AutoSize = true;
            this.radiohomme.Location = new System.Drawing.Point(40, 23);
            this.radiohomme.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radiohomme.Name = "radiohomme";
            this.radiohomme.Size = new System.Drawing.Size(77, 21);
            this.radiohomme.TabIndex = 5;
            this.radiohomme.TabStop = true;
            this.radiohomme.Text = "Homme";
            this.radiohomme.UseVisualStyleBackColor = true;
            // 
            // radioButtonFemme
            // 
            this.radioButtonFemme.AutoSize = true;
            this.radioButtonFemme.Location = new System.Drawing.Point(40, 50);
            this.radioButtonFemme.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonFemme.Name = "radioButtonFemme";
            this.radioButtonFemme.Size = new System.Drawing.Size(75, 21);
            this.radioButtonFemme.TabIndex = 4;
            this.radioButtonFemme.TabStop = true;
            this.radioButtonFemme.Text = "Femme";
            this.radioButtonFemme.UseVisualStyleBackColor = true;
            // 
            // labelAdrsse
            // 
            this.labelAdrsse.AutoSize = true;
            this.labelAdrsse.Location = new System.Drawing.Point(8, 76);
            this.labelAdrsse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAdrsse.Name = "labelAdrsse";
            this.labelAdrsse.Size = new System.Drawing.Size(60, 17);
            this.labelAdrsse.TabIndex = 4;
            this.labelAdrsse.Text = "Adresse";
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.Location = new System.Drawing.Point(8, 33);
            this.labelNom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(37, 17);
            this.labelNom.TabIndex = 3;
            this.labelNom.Text = "Nom";
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.buttonSubmit.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonSubmit.Location = new System.Drawing.Point(796, 69);
            this.buttonSubmit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(169, 28);
            this.buttonSubmit.TabIndex = 8;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = false;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonAfficher
            // 
            this.buttonAfficher.ForeColor = System.Drawing.SystemColors.GrayText;
            this.buttonAfficher.Location = new System.Drawing.Point(796, 105);
            this.buttonAfficher.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonAfficher.Name = "buttonAfficher";
            this.buttonAfficher.Size = new System.Drawing.Size(169, 28);
            this.buttonAfficher.TabIndex = 7;
            this.buttonAfficher.Text = "Afficher";
            this.buttonAfficher.UseVisualStyleBackColor = true;
            this.buttonAfficher.Click += new System.EventHandler(this.buttonAfficher_Click);
            // 
            // buttonFermer
            // 
            this.buttonFermer.Location = new System.Drawing.Point(796, 196);
            this.buttonFermer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonFermer.Name = "buttonFermer";
            this.buttonFermer.Size = new System.Drawing.Size(169, 28);
            this.buttonFermer.TabIndex = 9;
            this.buttonFermer.Text = "Fermer";
            this.buttonFermer.UseVisualStyleBackColor = true;
            this.buttonFermer.Click += new System.EventHandler(this.buttonFermer_Click);
            // 
            // buttoninitia
            // 
            this.buttoninitia.Location = new System.Drawing.Point(796, 150);
            this.buttoninitia.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttoninitia.Name = "buttoninitia";
            this.buttoninitia.Size = new System.Drawing.Size(169, 28);
            this.buttoninitia.TabIndex = 10;
            this.buttoninitia.Text = "Initialiser";
            this.buttoninitia.UseVisualStyleBackColor = true;
            this.buttoninitia.Click += new System.EventHandler(this.buttoninitia_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.buttoninitia);
            this.Controls.Add(this.buttonAfficher);
            this.Controls.Add(this.buttonFermer);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxLangue.ResumeLayout(false);
            this.groupBoxLangue.PerformLayout();
            this.groupBoxgenre.ResumeLayout(false);
            this.groupBoxgenre.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listville;
        private System.Windows.Forms.TextBox textNom;
        private System.Windows.Forms.TextBox textadresse;
        private System.Windows.Forms.Label labelAdrsse;
        private System.Windows.Forms.Label labelNom;
        private System.Windows.Forms.RadioButton radioButtonFemme;
        private System.Windows.Forms.RadioButton radiohomme;
        private System.Windows.Forms.GroupBox groupBoxgenre;
        private System.Windows.Forms.GroupBox groupBoxLangue;
        private System.Windows.Forms.CheckBox checkBoxC;
        private System.Windows.Forms.CheckBox checkCPLUS;
        private System.Windows.Forms.CheckBox checkC;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonAfficher;
        private System.Windows.Forms.Button buttonFermer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxville;
        private System.Windows.Forms.Button buttoninitia;
    }
}

