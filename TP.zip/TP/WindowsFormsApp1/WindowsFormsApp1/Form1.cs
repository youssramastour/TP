﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listville_SelectedIndexChanged(object sender, EventArgs e)
        {
            string value = listville.GetItemText(listville.SelectedItem);
            MessageBox.Show(value);
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            string nom = textNom.Text;
            string adresse = textadresse.Text;
            
            MessageBox.Show(nom +adresse);
        }

        private void buttonAfficher_Click(object sender, EventArgs e)
        {
            if (radioButtonFemme.Checked)
            {
                if (checkBoxC.Checked == true && checkC.Checked == false && checkCPLUS.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est une femme,elle distinct" + checkBoxC.Text);

                }
                if (checkC.Checked == true && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est une femme,elle distinct" + checkC.Text);

                }
                if (checkCPLUS.Checked == true && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est une femme,elle distinct" + checkCPLUS.Text);
                }
                if(checkCPLUS.Checked == true && checkBoxC.Checked == true && checkC.Checked == true)
                    {                    MessageBox.Show("L'utilisateur est une femme,elle distinct" + checkBoxC.Text+"," + checkC.Text +"et"+ checkCPLUS.Text); 
                        }
                if(checkCPLUS.Checked == false && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("l'utilisateur est une femme,elle ne distincte rien");
                }
            }
            else
                if(radiohomme.Checked)
            {
                if (checkBoxC.Checked == true && checkC.Checked == false && checkCPLUS.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est un homme,il distinct" + checkBoxC.Text);

                }
                if (checkC.Checked == true && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est un homme,il distinct" + checkC.Text);

                }
                if (checkCPLUS.Checked == true && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("L'utilisateur est un homme,il distinct" + checkCPLUS.Text);
                }
                if (checkCPLUS.Checked == true && checkBoxC.Checked == true && checkC.Checked == true)
                {
                    MessageBox.Show("L'utilisateur est un homme,il distinct" + checkBoxC.Text + "," + checkC.Text + "et" + checkCPLUS.Text);
                }
                if (checkCPLUS.Checked == false && checkBoxC.Checked == false && checkC.Checked == false)
                {
                    MessageBox.Show("l'utilisateur est un homme,il ne distincte rien");
                }
            }
        }
        /// autre methode de check, on utilisant evenement 
        /*
        private void chksport_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxC.Checked)

                MessageBox.Show("vous avez choisi le language .Net C ");
        }
        */
        private void buttonFermer_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Close();
        }

        private void buttoninitia_Click(object sender, EventArgs e)
        {
            textNom.Text = "";
            textadresse.Text = "";
            textNom.Focus();
        }
    }
}
