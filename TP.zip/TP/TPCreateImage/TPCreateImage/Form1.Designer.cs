﻿namespace TPCreateImage
{
    partial class FormPictureView
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanelView = new System.Windows.Forms.TableLayoutPanel();
            this.checkrecherche = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btmAfficher = new System.Windows.Forms.Button();
            this.btmClear = new System.Windows.Forms.Button();
            this.btmcolor = new System.Windows.Forms.Button();
            this.btmclose = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.pictureBoximage = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanelView.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoximage)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanelView
            // 
            this.tableLayoutPanelView.ColumnCount = 2;
            this.tableLayoutPanelView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanelView.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanelView.Controls.Add(this.pictureBoximage, 0, 0);
            this.tableLayoutPanelView.Controls.Add(this.checkrecherche, 0, 1);
            this.tableLayoutPanelView.Controls.Add(this.flowLayoutPanel1, 1, 1);
            this.tableLayoutPanelView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelView.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayoutPanelView.Name = "tableLayoutPanelView";
            this.tableLayoutPanelView.RowCount = 2;
            this.tableLayoutPanelView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.92405F));
            this.tableLayoutPanelView.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.07595F));
            this.tableLayoutPanelView.Size = new System.Drawing.Size(726, 359);
            this.tableLayoutPanelView.TabIndex = 1;
            // 
            // checkrecherche
            // 
            this.checkrecherche.AutoSize = true;
            this.checkrecherche.Location = new System.Drawing.Point(3, 303);
            this.checkrecherche.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkrecherche.Name = "checkrecherche";
            this.checkrecherche.Size = new System.Drawing.Size(75, 21);
            this.checkrecherche.TabIndex = 1;
            this.checkrecherche.Text = "Stretch";
            this.checkrecherche.UseVisualStyleBackColor = true;
            this.checkrecherche.CheckedChanged += new System.EventHandler(this.checkrecherche_CheckedChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btmAfficher);
            this.flowLayoutPanel1.Controls.Add(this.btmClear);
            this.flowLayoutPanel1.Controls.Add(this.btmcolor);
            this.flowLayoutPanel1.Controls.Add(this.btmclose);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(111, 303);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(612, 54);
            this.flowLayoutPanel1.TabIndex = 2;
            // 
            // btmAfficher
            // 
            this.btmAfficher.AutoSize = true;
            this.btmAfficher.Location = new System.Drawing.Point(489, 2);
            this.btmAfficher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btmAfficher.Name = "btmAfficher";
            this.btmAfficher.Size = new System.Drawing.Size(120, 27);
            this.btmAfficher.TabIndex = 0;
            this.btmAfficher.Text = "Show a picture";
            this.btmAfficher.UseVisualStyleBackColor = true;
            this.btmAfficher.Click += new System.EventHandler(this.btmAfficher_Click);
            // 
            // btmClear
            // 
            this.btmClear.AutoSize = true;
            this.btmClear.Location = new System.Drawing.Point(344, 2);
            this.btmClear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btmClear.Name = "btmClear";
            this.btmClear.Size = new System.Drawing.Size(139, 27);
            this.btmClear.TabIndex = 1;
            this.btmClear.Text = "Clear the picture";
            this.btmClear.UseVisualStyleBackColor = true;
            this.btmClear.Click += new System.EventHandler(this.btmClear_Click);
            // 
            // btmcolor
            // 
            this.btmcolor.AutoSize = true;
            this.btmcolor.Location = new System.Drawing.Point(144, 2);
            this.btmcolor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btmcolor.Name = "btmcolor";
            this.btmcolor.Size = new System.Drawing.Size(194, 27);
            this.btmcolor.TabIndex = 2;
            this.btmcolor.Text = "Set the background color";
            this.btmcolor.UseVisualStyleBackColor = true;
            this.btmcolor.Click += new System.EventHandler(this.btmcolor_Click);
            // 
            // btmclose
            // 
            this.btmclose.AutoSize = true;
            this.btmclose.Location = new System.Drawing.Point(70, 2);
            this.btmclose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btmclose.Name = "btmclose";
            this.btmclose.Size = new System.Drawing.Size(68, 27);
            this.btmclose.TabIndex = 3;
            this.btmclose.Text = "Close";
            this.btmclose.UseVisualStyleBackColor = true;
            this.btmclose.Click += new System.EventHandler(this.btmclose_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "JPEG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|BMP Files (*.bmp)|*.bmp|All file" +
    "s (*-*)|*-*";
            this.openFileDialog1.Title = "Select a picture file";
            // 
            // pictureBoximage
            // 
            this.pictureBoximage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tableLayoutPanelView.SetColumnSpan(this.pictureBoximage, 2);
            this.pictureBoximage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBoximage.Image = global::TPCreateImage.Properties.Resources.photo_1487073240288_854ac7f1bb3c;
            this.pictureBoximage.Location = new System.Drawing.Point(3, 2);
            this.pictureBoximage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBoximage.Name = "pictureBoximage";
            this.pictureBoximage.Size = new System.Drawing.Size(720, 297);
            this.pictureBoximage.TabIndex = 0;
            this.pictureBoximage.TabStop = false;
            // 
            // FormPictureView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 359);
            this.Controls.Add(this.tableLayoutPanelView);
            this.Name = "FormPictureView";
            this.Text = "Picture Viewer";
            this.tableLayoutPanelView.ResumeLayout(false);
            this.tableLayoutPanelView.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoximage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelView;
        private System.Windows.Forms.PictureBox pictureBoximage;
        private System.Windows.Forms.CheckBox checkrecherche;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btmAfficher;
        private System.Windows.Forms.Button btmClear;
        private System.Windows.Forms.Button btmcolor;
        private System.Windows.Forms.Button btmclose;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

